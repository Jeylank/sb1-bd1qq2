import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2, VolumeX } from 'lucide-react';
import axios from 'axios';

interface VoiceAssistantProps {
  onMessageReceived: (message: string) => void;
}

const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ onMessageReceived }) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState('');
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;

      recognitionRef.current.onresult = (event) => {
        const current = event.resultIndex;
        const transcript = event.results[current][0].transcript;
        setTranscript(transcript);
      };

      recognitionRef.current.onend = () => {
        if (isListening) {
          recognitionRef.current?.start();
        }
      };
    } else {
      console.error('Speech recognition not supported');
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [isListening]);

  const toggleListening = () => {
    setIsListening(!isListening);
    if (!isListening) {
      recognitionRef.current?.start();
    } else {
      recognitionRef.current?.stop();
      processTranscript(transcript);
    }
  };

  const processTranscript = async (text: string) => {
    try {
      const response = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: text }],
      }, {
        headers: {
          'Authorization': `Bearer ${process.env.REACT_APP_OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
      });

      const assistantResponse = response.data.choices[0].message.content;
      onMessageReceived(assistantResponse);
      speakResponse(assistantResponse);
    } catch (error) {
      console.error('Error processing transcript:', error);
      onMessageReceived("I'm sorry, I couldn't process that request. Can you try again?");
    }
  };

  const speakResponse = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } else {
      console.error('Speech synthesis not supported');
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  return (
    <div className="flex items-center space-x-2">
      <button
        onClick={toggleListening}
        className={`p-2 rounded-full ${isListening ? 'bg-red-500' : 'bg-blue-500'} text-white`}
      >
        {isListening ? <MicOff size={24} /> : <Mic size={24} />}
      </button>
      <button
        onClick={stopSpeaking}
        className={`p-2 rounded-full ${isSpeaking ? 'bg-green-500' : 'bg-gray-300'} text-white`}
        disabled={!isSpeaking}
      >
        {isSpeaking ? <Volume2 size={24} /> : <VolumeX size={24} />}
      </button>
      <p className="text-sm">{transcript}</p>
    </div>
  );
};

export default VoiceAssistant;