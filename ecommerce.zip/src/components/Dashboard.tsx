import React from 'react'
import { DollarSign, Package, RefreshCcw, Users, TrendingUp, ShoppingCart } from 'lucide-react'

// Mock data for demonstration purposes
const dashboardData = {
  totalSales: 15780,
  totalOrders: 324,
  totalReturns: 12,
  totalCustomers: 256,
  revenueGrowth: 8.5,
  conversionRate: 3.2,
  topSellingProducts: [
    { name: 'Wireless Earbuds', sales: 87 },
    { name: 'Smart Watch', sales: 65 },
    { name: 'Laptop Stand', sales: 54 },
  ],
}

const Dashboard: React.FC = () => {
  return (
    <div className="bg-gray-100 p-6 rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-6">Store Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DashboardCard
          title="Total Sales"
          value={`$${dashboardData.totalSales.toLocaleString()}`}
          icon={<DollarSign className="text-green-500" />}
        />
        <DashboardCard
          title="Total Orders"
          value={dashboardData.totalOrders.toString()}
          icon={<Package className="text-blue-500" />}
        />
        <DashboardCard
          title="Total Returns"
          value={dashboardData.totalReturns.toString()}
          icon={<RefreshCcw className="text-red-500" />}
        />
        <DashboardCard
          title="Total Customers"
          value={dashboardData.totalCustomers.toString()}
          icon={<Users className="text-purple-500" />}
        />
        <DashboardCard
          title="Revenue Growth"
          value={`${dashboardData.revenueGrowth}%`}
          icon={<TrendingUp className="text-yellow-500" />}
        />
        <DashboardCard
          title="Conversion Rate"
          value={`${dashboardData.conversionRate}%`}
          icon={<ShoppingCart className="text-indigo-500" />}
        />
      </div>
      <div className="mt-8">
        <h3 className="text-xl font-semibold mb-4">Top Selling Products</h3>
        <ul className="bg-white rounded-lg shadow">
          {dashboardData.topSellingProducts.map((product, index) => (
            <li key={index} className="flex justify-between items-center p-4 border-b last:border-b-0">
              <span>{product.name}</span>
              <span className="font-semibold">{product.sales} sales</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

interface DashboardCardProps {
  title: string
  value: string
  icon: React.ReactNode
}

const DashboardCard: React.FC<DashboardCardProps> = ({ title, value, icon }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow flex items-center">
      <div className="mr-4">{icon}</div>
      <div>
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="text-2xl font-bold">{value}</p>
      </div>
    </div>
  )
}

export default Dashboard