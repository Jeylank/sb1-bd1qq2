import React, { useState, useEffect } from 'react'
import { X, Send } from 'lucide-react'
import { getProducts, getProductByTitle, getInventoryLevels, getOrders } from '../services/shopifyService'
import VoiceAssistant from './VoiceAssistant'

interface Message {
  text: string
  isUser: boolean
}

interface ChatInterfaceProps {
  onClose: () => void
}

interface Product {
  id: number
  title: string
  variants: Array<{
    id: number
    price: string
  }>
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    { text: "Hello! Welcome to our store. How can I assist you today?", isUser: false }
  ])
  const [input, setInput] = useState('')
  const [products, setProducts] = useState<Product[]>([])

  useEffect(() => {
    const fetchProducts = async () => {
      const fetchedProducts = await getProducts();
      setProducts(fetchedProducts);
    };
    fetchProducts();
  }, []);

  const handleSend = () => {
    if (input.trim()) {
      setMessages([...messages, { text: input, isUser: true }])
      setInput('')
      setTimeout(() => {
        getBotResponse(input).then(response => {
          setMessages(prev => [...prev, { text: response, isUser: false }])
        })
      }, 500)
    }
  }

  const getBotResponse = async (userInput: string): Promise<string> => {
    const lowerInput = userInput.toLowerCase()

    // Check for product inquiries
    if (lowerInput.includes('product') || lowerInput.includes('item')) {
      const productName = lowerInput.replace('product', '').replace('item', '').trim()
      const product = await getProductByTitle(productName)
      if (product) {
        const inventory = await getInventoryLevels(product.id, product.variants[0].id)
        return `We have "${product.title}" in stock. The price is $${product.variants[0].price}. Current inventory: ${inventory} units.`
      } else {
        return "I'm sorry, I couldn't find that product. Can you try describing it differently?"
      }
    }

    // ... (rest of the existing conditions)

    // Default response
    return "I'm not sure I understand. Could you please rephrase your question? You can ask about our products, pricing, shipping, returns, or payment methods."
  }

  const handleVoiceMessage = (message: string) => {
    setMessages(prev => [...prev, { text: message, isUser: true }])
    getBotResponse(message).then(response => {
      setMessages(prev => [...prev, { text: response, isUser: false }])
    })
  }

  return (
    <div className="fixed bottom-4 right-4 w-96 h-[32rem] bg-white rounded-lg shadow-xl flex flex-col">
      <div className="bg-blue-600 text-white p-3 rounded-t-lg flex justify-between items-center">
        <h2 className="font-bold">Customer Support</h2>
        <button onClick={onClose} className="text-white hover:text-gray-200">
          <X size={20} />
        </button>
      </div>
      <div className="flex-grow overflow-y-auto p-4">
        {messages.map((message, index) => (
          <div key={index} className={`mb-2 ${message.isUser ? 'text-right' : 'text-left'}`}>
            <span className={`inline-block p-2 rounded-lg ${message.isUser ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-800'}`}>
              {message.text}
            </span>
          </div>
        ))}
      </div>
      <div className="p-3 border-t">
        <VoiceAssistant onMessageReceived={handleVoiceMessage} />
        <div className="flex mt-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your message..."
            className="flex-grow px-3 py-2 border rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={handleSend}
            className="bg-blue-500 text-white px-4 py-2 rounded-r-lg hover:bg-blue-600 transition-colors"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  )
}

export default ChatInterface