import React, { useState, useEffect } from 'react'
import { MessageSquare, LogOut } from 'lucide-react'
import ChatInterface from './components/ChatInterface'
import Dashboard from './components/Dashboard'
import AdminLogin from './components/AdminLogin'

function App() {
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    const authStatus = localStorage.getItem('isAdminAuthenticated')
    if (authStatus === 'true') {
      setIsAuthenticated(true)
    }
  }, [])

  const handleLogin = (status: boolean) => {
    setIsAuthenticated(status)
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    localStorage.removeItem('isAdminAuthenticated')
  }

  if (!isAuthenticated) {
    return <AdminLogin onLogin={handleLogin} />
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-blue-600 text-white p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold">Your E-commerce Store</h1>
        <button
          onClick={handleLogout}
          className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition-colors flex items-center"
        >
          <LogOut size={20} className="mr-2" />
          Logout
        </button>
      </header>
      <main className="flex-grow p-4">
        <Dashboard />
      </main>
      {isChatOpen && <ChatInterface onClose={() => setIsChatOpen(false)} />}
      {!isChatOpen && (
        <button
          onClick={() => setIsChatOpen(true)}
          className="fixed bottom-4 right-4 bg-blue-500 text-white p-3 rounded-full shadow-lg hover:bg-blue-600 transition-colors"
        >
          <MessageSquare size={24} />
        </button>
      )}
    </div>
  )
}

export default App