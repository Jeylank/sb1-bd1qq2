import axios from 'axios';

// This would be your Shopify store URL
const SHOPIFY_URL = process.env.REACT_APP_SHOPIFY_URL;
// This would be your Shopify access token
const SHOPIFY_ACCESS_TOKEN = process.env.REACT_APP_SHOPIFY_ACCESS_TOKEN;

const shopifyApi = axios.create({
  baseURL: `https://${SHOPIFY_URL}/admin/api/2023-04`,
  headers: {
    'Content-Type': 'application/json',
    'X-Shopify-Access-Token': SHOPIFY_ACCESS_TOKEN
  }
});

export const getProducts = async () => {
  try {
    const response = await shopifyApi.get('/products.json');
    return response.data.products;
  } catch (error) {
    console.error('Error fetching products:', error);
    return [];
  }
};

export const getProductByTitle = async (title: string) => {
  try {
    const response = await shopifyApi.get(`/products.json?title=${encodeURIComponent(title)}`);
    return response.data.products[0];
  } catch (error) {
    console.error('Error fetching product:', error);
    return null;
  }
};

export const getInventoryLevels = async (productId: number, variantId: number) => {
  try {
    const response = await shopifyApi.get(`/products/${productId}/variants/${variantId}.json`);
    return response.data.variant.inventory_quantity;
  } catch (error) {
    console.error('Error fetching inventory levels:', error);
    return null;
  }
};

export const getOrders = async () => {
  try {
    const response = await shopifyApi.get('/orders.json');
    return response.data.orders;
  } catch (error) {
    console.error('Error fetching orders:', error);
    return [];
  }
};